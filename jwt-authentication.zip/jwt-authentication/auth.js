const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');

const secretKey = 'your_secret_key'; // Replace with your secret key for JWT token

const users = [];

const register = (req, res) => {
    const { username, password } = req.body;

    const existingUser = users.find((user) => user.username === username);
    if (existingUser) {
        return res.status(409).json({ error: 'Username already exists' });
    }

    bcrypt.hash(password, 10, (err, hashedPassword) => {
        if (err) {
            console.error('Error hashing password:', err);
            return res.status(500).json({ error: 'An error occurred during registration' });
        }

        const newUser = {
            username,
            password: hashedPassword,
        };

        users.push(newUser);

        res.sendStatus(200);
    });
};

const login = (req, res) => {
    const { username, password } = req.body;

    const user = users.find((user) => user.username === username);
    if (!user) {
        return res.status(401).json({ error: 'Invalid username or password' });
    }

    bcrypt.compare(password, user.password, (err, result) => {
        if (err) {
            console.error('Error comparing passwords:', err);
            return res.status(500).json({ error: 'An error occurred during login' });
        }

        if (result) {
            const token = jwt.sign({ username: user.username }, secretKey);
            res.cookie('token', token, { httpOnly: true });
            return res.json({ message: 'Logged in successfully!' });
        }

        res.status(401).json({ error: 'Invalid username or password' });
    });
};

const logout = (req, res) => {
    res.clearCookie('token');
    res.json({ message: 'Logged out successfully!' });
};

module.exports = {
    register,
    login,
    logout,
};
