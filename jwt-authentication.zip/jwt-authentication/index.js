document.addEventListener('DOMContentLoaded', () => {
    const registerForm = document.getElementById('registerForm');
    const registerAlert = document.getElementById('registerAlert');
    const loginForm = document.getElementById('loginForm');
    const loginAlert = document.getElementById('loginAlert');
    const logoutButton = document.getElementById('logoutButton');
    const logoutAlert = document.getElementById('logoutAlert');

    registerForm.addEventListener('submit', (event) => {
        event.preventDefault();
        const username = document.getElementById('registerUsername').value;
        const password = document.getElementById('registerPassword').value;
        register(username, password);
    });

    loginForm.addEventListener('submit', (event) => {
        event.preventDefault();
        const username = document.getElementById('loginUsername').value;
        const password = document.getElementById('loginPassword').value;
        login(username, password);
    });

    logoutButton.addEventListener('click', logout);

    function register(username, password) {
        fetch('/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ username, password }),
        })
            .then((response) => {
                if (response.ok) {
                    registerForm.reset();
                    registerAlert.style.display = 'block';
                } else {
                    console.error('Registration failed:', response);
                }
            })
            .catch((error) => {
                console.error('Error during registration:', error);
            });
    }

    function login(username, password) {
        fetch('/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ username, password }),
        })
            .then((response) => {
                if (response.ok) {
                    loginForm.reset();
                    loginAlert.style.display = 'block';
                    logoutButton.style.display = 'block';
                    logoutAlert.style.display = 'none';
                } else {
                    console.error('Login failed:', response);
                }
            })
            .catch((error) => {
                console.error('Error during login:', error);
            });
    }

    function logout() {
        fetch('/logout', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
        })
            .then((response) => {
                if (response.ok) {
                    logoutButton.style.display = 'none';
                    logoutAlert.style.display = 'block';
                } else {
                    console.error('Logout failed:', response);
                }
            })
            .catch((error) => {
                console.error('Error during logout:', error);
            });
    }
});
