const express = require('express');
const auth = require('./auth');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
//const cookieParser = require('cookie-parser');

const app = express();
const port = 3000;
const secretKey = 'sanket'; // Replace with your secret key for JWT token

app.use(express.json());


app.use(express.static(__dirname));

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
});

app.post('/register', auth.register);
app.post('/login', auth.login);
app.post('/logout', auth.logout);

app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});
